git add *.py
git commit -m '.'
git push origin master

